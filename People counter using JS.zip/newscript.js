let saveEL = document.getElementById("saver") 
let counted = document.getElementById("counter")
let count = 0


function increment() {
    count += 1
    counted.textContent = count
}

function save() {
    let countstr = count + "-"
    saveEL.textContent += countstr
    counted.textContent = 0
    count = 0
}

let userScore = 0

function add3points() {
    userScore += 3
}

function decrese1point() {
    userScore -= 1
}

